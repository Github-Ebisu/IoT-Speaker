package com.example.spotifour;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
